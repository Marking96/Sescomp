<!-- ==============================================
Register
=============================================== -->

<!--<section class="register darker-background" id="register">
  <div class="container">
    <div class="row">
      <div class="span5">
        <h2 class="no-margin-bottom">Inscríbete</h2>-->

<!--
        <h4>Completa aquí tus datos:</h4>
        <form action="send-mail.php" method="post" id="contact-form">
          <input type="text" value="Tu nombre" name="name" class="required">
          <input type="text" value="Tu email" name="email" class="required email">
          <div class="checkbox-container">
            <input type="checkbox" name="agree" id="agree" class="required">
            <div class="checkbox-placeholder"></div>
            <label for="agree" class="label-checkbox">
              Yes, I would like to subscribe and I accept the <a href="">Terms and Conditions</a>. We will not forward your email address to any third party.
            </label>
          </div>

          <a href="http://www.eventbrite.es/event/7714136189">
            <input type="submit" name="register" value="Inscribirme">
          </a>

        </form>
-->
<!--
          <form>
          <a href="http://www.eventbrite.es/event/7714136189">
            <input type="submit" name="register" value="Completar mi inscripción">
          </a>
</form>

      </div>

      <div class="span6 offset1">
        <p>Quisque vel justo ipsum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Duis rutrum risus quis est faucibus a consequat massa sagittis. Cras bibendum elit id felis dapibus volutpat.<br>
</p>

-->

        <!--
        <h3>Downloads</h3>
        <ul class="downloads">
          <li><a href="#"><i class="icon-download-alt"></i> Complete 2013 Event Edition calendar</a></li>
          <li><a href="#"><i class="icon-download-alt"></i> Event rules</a></li>
          <li><a href="#"><i class="icon-download-alt"></i> Reporters registration 2013</a></li>
        </ul>
        -->
    <!--  </div>
    </div>
  </div>
</section>-->
<!-- End Register
============================================== -->

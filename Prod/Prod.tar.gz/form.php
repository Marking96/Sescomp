<?php

echo "teste";

 ?>

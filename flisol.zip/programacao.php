<!-- ==============================================
Program
=============================================== -->
<!-- <section class="program light-gray-background" id="programa">
  <div class="container">
    <div class="row">
      <div class="span12">
        <h2 class="no-margin-bottom">Programação</h2>
        <h4>O que vai ter no FLISOL Vale 2016!</h4>
        <ul class="niveles">
          <li class="circulo verde"><span>Iniciante</span></li>
          <li class="circulo azul"><span>Médio</span></li>
          <li class="circulo rojo"><span>Avançado</span></li>
        </ul>

      </div>
    </div>

<div class="row">
      <div class="span12">
        <table>
          <thead>
            <tr>
              <td colspan="3">
                <h3>Sábado, 28 Septiembre 2013</h3>
              </td>
            </tr>
            <tr class="heading">
              <td class="column-one"><h4>Hora</h4></td>
              <td class="column-two center"><h4>Sala 1 | Word</h4></td>
              <td class="column-three center"><h4>Sala 2 | Press</h4></td>
            </tr>
          </thead>
          <tbody>
            <tr class="odd">
              <td class="column-one">9:00</td>
              <td class="column-two center" colspan="2"><em>Apertura y acreditaciones</em></td>
            </tr>
            <tr class="even">
              <td class="column-one">9:30</td>
              <td class="column-two">
                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>

                Conoce WordPress y sácale el máximo rendimiento a tu PYME
                <em><a href="http://twitter.com/MerchanJavier">Javier Merchán</a></em>

              </td>
              <td class="column-three">
                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>
                ¡Adiós Joomla! ¡Hola WordPress! La experiencia en <a href="http://laramblanoticias.com">laramblanoticias.com</a>
                <em><a href="http://twitter.com/sergiormb">Sergio Pino</a></em>
              </td>
            </tr>
            <tr class="odd">
              <td class="column-one">10:10</td>

              <td class="column-two">
                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>
                Hackers vs WordPress: Seguridad en WordPress
                <em><a href="http://twitter.com/miguel_arroyo76">Miguel Ángel Arroyo</a></em>


              <td class="column-three">Mapas en WordPress
              <em><a href="http://twitter.com/sigdeletras">Patricio Soriano</a></em>
                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>
              </td>

            </tr>
            <tr class="even">
              <td class="column-one">10:50</td>
              <td class="column-two center" colspan="2">Café y charlas</td>

            </tr>
            <tr class="odd">
              <td class="column-one">11:20</td>
              <td class="column-two">
                <div class="circulo rojo"> </div>
                <div class="circulo azul"> </div>
                Back to the future: blogs estáticos vs. WordPress
                <em><a href="http://twitter.com/javiburon">Javier Burón</a></em>
                <!--
                ¿Tienes una propuesta?
                <a href="mailto:info@wpcordoba.org">Aquí tu ponencia</a></em>

              </td>
              <td class="column-three">

                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>
                WP Wizard 2, un gestor de WordPress para Windows
              <em><a href="http://twitter.com/fjaviersantos">Javier Santos</a></em>

              </td>
            </tr>
            <tr class="even">
              <td class="column-one">12:00</td>
              <td class="column-two">


              <div class="circulo azul"> </div>
              <div class="circulo verde"> </div>
              Monetizar con WordPress
              <em><a href="http://twitter.com/fjcarazo">Francisco Javier Carazo</a></em>
              </td>
              <td class="column-three">
                <div class="circulo rojo"> </div>
                <div class="circulo azul"> </div>

                Temas y plugins en WordPress 3.6+: Manual de buenas prácticas de programación.
                <em><a href="http://twitter.com/bi0xid">Rafael Poveda</a></em>

              </td>
            </tr>
            <tr class="odd">
              <td class="column-one">12:40</td>
              <td class="column-two">
                <div class="circulo rojo"> </div>
                Composer en WordPress
                <em><a href="http://twitter.com/hidabe">Fernando Hidalgo</a></em>
              </td>
              <td class="column-three">
                <div class="circulo azul"> </div>
                <div class="circulo verde"> </div>
                Seguridad en WordPress
                <em><a href="http://twitter.com/josecontic">Jose Conti</a></em>

                ¿Tienes una propuesta?
                <a href="mailto:info@wpcordoba.org">Aquí tu ponencia</a></em>

              </td>
            </tr>
            <tr class="even">
              <td class="column-one">13:20</td>
              <td class="column-two center" colspan="2"><em>Despedida y cierre</em></td>
            </tr>
            <tr class="odd">
              <td class="column-one">13:30</td>
              <td class="column-two center" colspan="2"><em>Fin de la jornada</em></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>



    <div class="row" id="workshops">
      <div class="span12">
        <h2 class="no-margin-bottom">Talleres</h2>
        <h4>El viernes a la tarde, participa en los talleres.</h4>
        <ul class="niveles">
          <li class="circulo verde"><span>Principiante</span></li>
          <li class="circulo azul"><span>Iniciado</span></li>
          <li class="circulo rojo"><span>Avanzado</span></li>
        </ul>
      </div>
    </div>

    <div class="row">
      <div class="span12">
        <table>
          <thead>
            <tr>
              <td colspan="2">
                <h3>Viernes, 27 Septiembre 2013 | ¡Aforo completo!</h3>
              </td>
            </tr>
          </thead>
          <tbody>
          <tr class="even">
            <td class="column-one">16:45</td>
            <td class="column-two center" colspan="2"><em>Apertura y acreditaciones</em></td>
          </tr>
            <tr class="odd">
              <td class="column-one">17:00</td>
              <td class="column-two">
              <div class="circulo verde"> </div>
              Iniciación a WordPress: ¡empezamos desde cero!
              <em><a href="http://twitter.com/davidmerinas">David Merinas</a></em>
              </td>
            </tr>
            <tr class="even">
              <td class="column-one">18:00</td>
              <td class="column-two">
              <div class="circulo rojo"> </div>
              WordPress a medida: programación de un Custom Post Type <em><a href="http://twitter.com/sgomez">Sergio Gómez</a></em>

              </td>
            </tr>
            <tr class="odd">
              <td class="column-one">19.00</td>
              <td class="column-two">
              <div class="circulo rojo"> </div>
              Introducción al desarrollo de plugins <em><a href="http://twitter.com/fjcarazo">Francisco Javier Carazo</a></em>
</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</section>
-->

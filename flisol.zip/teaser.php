<!-- ==============================================
Teaser
=============================================== -->
<section class="teaser">
  <div class="container">
    <div class="row">

      <!-- ==============================================
      Text
      =============================================== -->
      <div class="span7 offset5 text-container maintitle">
        <h1>Aprenda, ensine, compartilhe.</h1>
        <h2>II FLISOL Vale do Jaguaribe - Russas</h2>
      </div>
      <!-- End Text
      =============================================== -->

    </div>
  </div>
</section>
<!-- End Teaser
============================================== -->

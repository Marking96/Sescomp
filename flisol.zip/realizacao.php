<!-- ==============================================
		Sponsor
		=============================================== -->
		<section class="sponsor white-background">

			<div class="container">
				<div class="row">

				<div class="span12">
						<h2 class="no-margin-bottom">REALIZAÇÃO</h2>

					</div>
					<div class="span2 text-center logo-fina">
						<img src="http://valelivre.org/wp-content/images/logos/realizacao/ufc.png" alt="" >
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://valelivre.org"><img src="http://valelivre.org/wp-content/images/logos/realizacao/valelivre.png" alt=""></a>
					</div>

					<div class="span2 tex-center logo-onadi">
						<a href="http://onadi.org.br"><img src="http://valelivre.org/wp-content/images/logos/realizacao/onadi.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://campusrussas.ufc.br"><img src="http://valelivre.org/wp-content/images/logos/realizacao/comp.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://campusrussas.ufc.br"><img src="http://valelivre.org/wp-content/images/logos/realizacao/sof.png" alt="logo libreria luque"></a>
					</div>

<div class="span12">
						<h2 class="no-margin-bottom">PATROCINADOR OURO</h2>

					</div>
					<div class="span2 text-center logo-fina">
						<img src="http://valelivre.org/wp-content/images/logos/ouro/kadoo.png" alt="">
					</div>

					<div class="span2 text-center logo-path">
						<a href="http://www.pathfind.com.br"><img src="http://valelivre.org/wp-content/images/logos/ouro/path.png" alt=""></a>
					</div>

					<!--<div class="span2 text-center logo-fina">
						<a href="http://unopar.edu.br"><img src="http://valelivre.org/wp-content/images/logos/ouro/unopar.png" alt=""></a>
					</div>-->




					<div class="span12">
						<h2 class="no-margin-bottom">PATROCINADOR BRONZE</h2>

					</div>
					<div class="span2 text-center logo-fina">
						<img src="http://valelivre.org/wp-content/images/logos/bronze/maravilha.png" alt="">
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://www.uco.es/aulasoftwarelibre/"><img src="http://valelivre.org/wp-content/images/logos/bronze/mega.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fina">
						<a href="https://www.facebook.com/dinamicosociocultural"><img src="http://valelivre.org/wp-content/images/logos/bronze/milena.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fisk">
						<a href="http://www.librerialuque.es"><img src="http://valelivre.org/wp-content/images/logos/bronze/fisk.png" alt="logo libreria luque"></a>
					</div>

<div class="span12">
						<h2 class="no-margin-bottom">APOIO</h2>

					</div>
					<div class="span2 text-center logo-yeloo">
						<img src="http://valelivre.org/wp-content/images/logos/apoio/yeloo.png" alt="">
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://ifce.edu.br"><img src="http://valelivre.org/wp-content/images/logos/apoio/IF.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://novatec.com.br"><img src="http://valelivre.org/wp-content/images/logos/apoio/novatec.png" alt=""></a>
					</div>

					<div class="span2 text-center logo-fina">
						<a href="http://mafaldamagazine.com.br"><img src="http://valelivre.org/wp-content/images/logos/apoio/mafalda.png" alt=""></a>
					</div>
				</div>
			</div>


		</section>
		<!-- End Sponsor
		============================================== -->

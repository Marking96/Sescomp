<!-- ==============================================
Footer
=============================================== -->
<section class="footer dark-gray-background">
  <div class="container">
    <div class="row">
      <div class="span6">
        <p class="no-margin-bottom">
        </p>
      </div>
      <!-- ==============================================
      Social
      =============================================== -->
      <div class="span6">
        <ul class="social float-right">
          <!--<li><a href="#"><i class="icon-google-plus"></i></a></li>-->
          <li><a href="http://www.twitter.com/flisolvale"><i class="icon-twitter"></i></a></li>
          <li><a href="http://www.fb.com/flisolvale"><i class="icon-facebook"></i></a></li>

          <!--<li><a href="#"><i class="icon-facebook"></i></a></li>-->
        </ul>
        <p class="no-margin-bottom float-right copyright"><a href="#"></a></p>
      </div>
      <!-- End Social
      ============================================== -->
    </div>
  </div>
</section>
<!-- End Footer
============================================== -->

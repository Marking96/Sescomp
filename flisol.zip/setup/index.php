<?php

require("cabecalho.php");
require("includes/makeInput.php");

if(!isset($_SESSION['idUsuario'])){
/* Direciona para a página depois de logado */
echo '<script type="text/javascript">location = "login"</script>';
exit;	// sai da página para n exibir o restante do documento php

}


?>
<title>Inscrição - II FLISOL Vale</title>
	</head>
	<body id="top" class="fixed-nav">

		<?php require("menu-topo.php"); ?>

    <section class="intro white-background" id="formulario">
      <div class="container">
        <div class="row">

					<div class="span12">
						<h2 class="padding-top">Administrador <span>FLISOL Vale</span> |
              <small><?php echo $_SESSION["nomeUsuario"] ?> - <a href="sair.php">sair</a></small></h2>
							<div id="apresentacao" style="margin-top:40px">
							<h2>Seja bem vindo ao formulário de inscrição do Flisol Vale 2016!</h2>


							</div>
					</div>



          </div>

      </div>
    </section>

		<?php require("rodape.php"); ?>

<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo $urlBase; ?>js/vendor/jquery.mask.js"></script>
<script type="text/javascript">

	$('#inicio').mask('00:00');
	$('#termino').mask('00:00');

  $(".alert").alert();

</script>

	</body>
</html>

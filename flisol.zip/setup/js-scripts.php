<!-- ==============================================
JS
=============================================== -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.min.js"></script> <!-- jQuery main file -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.flexslider.min.js"></script> <!-- Flexslider -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.easing.pack.js"></script> <!-- Easing for Fancybox -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.mousewheel.pack.js"></script> <!-- Mousewheel for Fancybox -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.fancybox.pack.js"></script> <!-- Fancybox -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/jquery.validate.min.js"></script> <!-- Form Validation -->
<script type="text/javascript" src="<?php echo $urlBase; ?>js/attraction.js"></script> <!-- Custom JS -->

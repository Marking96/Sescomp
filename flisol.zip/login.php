<?php

require("cabecalho.php");

if(isset($_POST['logar'])){

require('includes/class.login.php');

$login = new Login();
	
$login->set($_POST['login'], 'login')->obrigatorio();
$login->set($_POST['senha'], 'senha')->obrigatorio();

$lembrar = filter_input(INPUT_POST, 'lembrar');
	
	if($login->validar()){

		$sql = "SELECT id_colaborador,nome,apelido,ultimo_acesso,permissao FROM colaborador WHERE ((email = ? AND senha = ?) OR (login = ? AND senha =?)) AND situacao <> 'inativo'";
				
		$param = array($_POST['login'], md5($_POST['senha']),$_POST['login'], md5($_POST['senha']));
		
		$qryUser = $pdo->prepare($sql);
		$qryUser->execute($param);
		
		$res = $qryUser->fetch(PDO::FETCH_ASSOC);		
		
		if($qryUser->rowCount() <= 0){
			$erro[0] = '<strong>Erro:</strong> Usu&aacute;rio inv&aacute;lido';
		}else{
			
			if(isset($lembrar)){
			
				$tempo = strtotime('+7 days');

                setcookie('login', $_POST['login'], $tempo);

                setcookie('pass', $_POST['senha'], $tempo);

			
			}else{
			
				$tempo = strtotime('-1 hour');
			
				setcookie('login', '', $tempo);

                setcookie('pass', '', $tempo);
			
			}
			
			
			$_SESSION['idColab']    	= $res['id_colaborador'];
			$_SESSION['nomeColab']   	= $res['nome'];
			$_SESSION['permissaoColab']   = $res['permissao'];
			$_SESSION['apelidoColab']   = $res['apelido'];
			$_SESSION['timestamp'] 		= $res['ultimo_acesso'];
			
			if($res['ultimo_acesso'] == '0000-00-00 00:00:00'){
			
				/* Se não tiver ultimo acesso vai para cadastro */
				$qryUpdate = $pdo->prepare("UPDATE colaborador SET ultimo_acesso=NOW(), situacao='ativo', se_online=1 WHERE id_colaborador=?");
				$qryUpdate->execute(array($res['id_colaborador']));
				
				echo '<script type="text/javascript">location = "'.$urlBase.'cadastro"</script>';
				exit;
				
			}else{
			
				$qryUpdate = $pdo->prepare("UPDATE colaborador SET ultimo_acesso=NOW(), se_online=1 WHERE id_colaborador=?");
				$qryUpdate->execute(array($res['id_colaborador']));
				
				echo '<script type="text/javascript">location = "'.$urlBase.'"</script>';
				exit;
				
			}				
			
			
		
		}	
				
	}else{

		$erro = $login->erros();

	}
	
}


?>
<title>ProGame - Gamificando seu Aprendizado!</title>
</head>
<body>

<?php

require("menu-topo.php");
?>

<!-- Conteudo -->
<div class="container-fluid">
	
<div id="myCarousel" class="carousel slide">

<div class="carousel-inner login">
<!-- Item de recuperacao de login -->
<div class="active item">


<!-- Formulario de Login -->
<form class="col-sm-3 form-login" action="#" method="post" style="margin: 0 auto; float:none">

<legend>Entre em sua Conta</legend>

<?php if(isset($erro)){ ?>
		<div class="alert alert-error">
		<?php echo $erro[0]; ?> <a class="close fade" data-dismiss="alert" href="#">&times;</a>
		</div>
	<?php } ?>

<div class="form-group">
<a href="#fakelink" class="btn btn-block btn-social-facebook">
<span class="fui-facebook"></span>
Conectar com o Facebook
</a>
</div>

<div class="form-group">
    <label for="inputEmail">Email ou login</label>
    <input type="text" class="form-control" id="inputEmail" value="<?php if(isset($_COOKIE['login'])) echo $_COOKIE['login']; else echo $_POST['login']; ?>" placeholder="Digite seu E-mail ou Login">
  </div>
  
<div class="form-group">
	<label for="inputSenha">Senha</label>
	<input type="password" class="form-control" value="<?php if(isset($_COOKIE['pass'])) echo $_COOKIE['pass']; ?>" id="inputSenha" name="senha" placeholder="Senha">
</div>

<div class="form-group">
	<input type="submit" name="logar" class="btn btn-block btn-success" value="Entrar" />
</div>

<div class="form-group">
<div class="row">
  <div class="col-xs-5">
    <label class="checkbox">
	<input type="checkbox" name="lembrar" id="lembrar" value="ok" <?php if(isset($_COOKIE['login']) && isset($_COOKIE['pass'])) echo 'checked'; ?> data-toggle="checkbox" /> Lembrar-me
	</label>

          
  </div>
  <div class="col-xs-7">
	  <label class="checkbox">
    <a href="<?php echo $urlLogin;?>#senha" data-target="#myCarousel" data-slide-to="1">Esqueci a senha</a>
    </label>
  </div>
  
<div class="cuidado" style="background:#FFC9C9; border:1px solid red; padding:5px; margin:3px 0px; display:none;">
<p><strong>IMPORTANTE!</strong> Caso esteja em um computador n&atilde;o seguro, desmarque esse campo</p>
</div>  
</div>
</div>



</form>

</div>


<!-- Item de recuperacao de senha -->
<div class="item">


	
	<form class="col-sm-3 form-login" action="#" method="post" style="margin: 0 auto; float:none">
		<legend>Recuperar Senha</legend>
		
		<?php if(isset($erro)){ ?>
		<div class="alert alert-error">
		<?php echo $erro[0]; ?>
		</div>
	<?php } ?>
	
	<div class="form-group">
		<label class="control-label" for="inputEmail">Email</label>
		<div class="controls">
		<input type="text" name="login" id="inputEmail" class="form-control" placeholder="email@anjodaguarda.com" value="<?php echo $_POST['login']; ?>" />
		</div>
	</div>
	<div class="form-group">
		<div class="row">
		<div class="col-sm-6">
		<a href="<?php echo $urlLogin;?>#login" class="text-danger" data-target="#myCarousel" data-slide-to="0">Cancelar</a>
		</div>
		
		<div class="col-sm-6">
			<input type="submit" name="logar" class="btn btn-success" value="Recuperar" />
		</div>
		
		</div>
		
	</div>

	
	</form>


</div>
</div>

</div>

</div><!-- fim do container -->

<?php

require("rodape.php");

?>


<?php

require("js-scripts.php");

?>

<script type="text/javascript">
// carousel demo
$('#myCarousel').carousel({interval: false});
$(".alert").alert();

if($('#lembrar').is(':checked')){
	$('.cuidado').fadeIn();
}

$('#lembrar').click(function(){

	if($(this).is(':checked')){
		$('.cuidado').fadeIn();
	}else{
		$('.cuidado').fadeOut().html();
	}

});

</script>

</body>
</html>

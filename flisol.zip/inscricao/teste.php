<?php


echo date('Y-m-d',strtotime("30/04/2014"));

 ?>

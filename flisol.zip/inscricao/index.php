<?php
require("../cabecalho.php");
require("../includes/makeInput.php");
require("../includes/funcoes.php");


if(isset($_POST['envio'])){

$nome				= filter_input(INPUT_POST, 'nome');
$cpf				= filter_input(INPUT_POST, 'cpf');
$email			= filter_input(INPUT_POST, 'email');
$cemail			= filter_input(INPUT_POST, 'cemail');
$telefone1	= filter_input(INPUT_POST, 'telefone1');
$cep				= filter_input(INPUT_POST, 'cep');
$cidade			= filter_input(INPUT_POST, 'cidade');
$uf					= filter_input(INPUT_POST, 'uf');
$nascimento	= filter_input(INPUT_POST, 'nascimento');
$escolaridade	= filter_input(INPUT_POST, 'escolaridade');
$ocupacao		= filter_input(INPUT_POST, 'ocupacao');
$iniciativa	= filter_input(INPUT_POST, 'iniciativa');
$instEnsino	= filter_input(INPUT_POST, 'instEnsino');
$sexo	= filter_input(INPUT_POST, 'sexo');

$minicursos = $_POST['oficinas'];

$qryCPF = $pdo->prepare("SELECT cpf FROM participante WHERE cpf = ?");
$qryCPF->execute(array($cpf));
if($qryCPF->rowCount() > 0){
	$hasCPF = true;
}else{
	$hasCPF = false;
}

	if(empty($nome)){
		$erro = true;
		$msg = "Informe seu Nome";
	}elseif(empty($cpf) || !validaCPF(limpaCPF_CNPJ($cpf)) ){
		$erro = true;
		$msg = 'Algum problema com o seu CPF';
	}elseif($hasCPF){
		$erro = true;
		$msg = 'Seu CPF já foi informado. Entre em contato com a equipe do Flisol caso exista algum erro';
	}elseif(empty($email) || $email != $cemail || !filter_var($email, FILTER_VALIDATE_EMAIL)){
		$erro = true;
		$msg = 'Verifique se informou um E-mail correto e/o confirmou';
	}elseif(empty($telefone1)){
		$erro = true;
		$msg = 'Informe pelo menos um telefone para contato';
	}elseif(empty($cidade) || empty($uf) || empty($cep)){
		$erro = true;
		$msg = 'Suas informações de endereços não foram informadas';
	}else{

		$param = array($nome,limpaCPF_CNPJ($cpf),$email,$telefone1,$cep,
		$cidade,$uf,date('Y-m-d',strtotime($nascimento)),$escolaridade,
		$ocupacao,$iniciativa,$instEnsino,$sexo);
		$qryInserir = $pdo->prepare("INSERT INTO participante SET
			nome=?,cpf=?,email=?,telefone1=?,cep=?,
			cidade=?,uf=?,data_nasc=?,escolaridade=?,
			ocupacao=?,iniciativa=?,instensino=?,sexo=?,
			data_cadastro=NOW()");
		$qryInserir->execute($param);

		if($qryInserir->rowCount() <= 0){
			$erro = true;
			$msg = "Erro ao cadastrar, tente novamente.";
			$debug = $qryInserir->errorInfo();
			$msg .= "<br/>". $debug[2];
		}else{
			$ok = true;

			// Cadastro das respostas
				$ultimoId = $pdo->lastInsertId('id_participante');

				foreach($minicursos as $v){
					if(!empty($v)){

						//Verifica se tem vaga
						$qryVagas = $pdo->query("Select vagas_disp FROM atividade WHERE id_atividade = $v");
						$vagas = $qryVagas->fetchObject();
						$totalVagas = $vagas->vagas_disp;

		if($totalVagas > 0){
		$qryResposta = $pdo->prepare("INSERT INTO atividade_participante SET id_atividade=?, id_participante=?");
		$qryResposta->execute(array($v,$ultimoId));

		// Atualiza o número de Vagas
		$totalVagas--;
		$qryUpdate = $pdo->query("UPDATE atividade SET vagas_disp = $totalVagas
			WHERE id_atividade = $v;");

		}


					}

				}


			$msg = "Inscrição realizada com Sucesso!";


// Envio de E-mail para o participante

require 'includes/PHPMailer-master/PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'br14.hostgator.com.br';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'Flisol Vale 2016';                 // SMTP username
$mail->Password = 'ciVPT3SXX,TN';                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 465;                                    // TCP port to connect to

$mail->setFrom('flisol@valelivre.org', 'Flisol Vale 2016');
$mail->addAddress($email, $nome);     // Add a recipient
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = "Seja bem vindo ao Flisol Vale 2016!";
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = 'Seja bem vindo ao Flisol Vale 2016! Sua inscrição foi realizada com sucesso.';

if(!$mail->send()) {
    $msg .= 'Message could not be sent.';
    $msg .= 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    $msg .= '. Sua confirmação de inscrição foi enviada para seu e-mail.';
}

		}


		}

	}


?>
<title>Inscrição - II FLISOL Vale</title>
	</head>
	<body id="top" class="fixed-nav">

		<?php require("../menu-topo.php"); ?>

    <section class="intro white-background" id="formulario">
      <div class="container">
        <div class="row">

          <div class="span12" id="about">
            <h2 class="padding-top">Inscreva-se no <span>FLISOL Vale</span></h2>

	<div id="apresentacao">
		<h3>Seja bem vindo ao formulário de inscrição do Flisol Vale 2016!</h3>
<p>
	Para evitar erros durante sua inscrição esteja atento às informações preenchidas e em caso de dúvidas entre em contato com a equipe do evento via o e-mail contato[arroba]valelivre[ponto]org. Lembrando que as informações fornecidas serão utilizadas para confecção de certificados e/ou crachás. <strong>A equipe do Flisol Vale 2016 deseja um bom proveiro das atividades!</strong>
</p>

<?php
if($ok) alert($msg,"success");
if($erro) alert($msg,"error");

 ?>

<?php if(!$ok){ ?>

	<form class="form-horizontal" method="POST" action="">
	<h2>Seus Dados</h2>
	<?php

	input("nome","Nome Completo","input-xlarge","nome","Seu Nome Completo",true,$_POST["nome"]);
	input("cpf","CPF","cpf","cpf","Seu CPF",true,$_POST["cpf"],"text","","inputCPF");
	input("email","E-mail","input-xlarge","email","Insira seu E-mail",true,$_POST["email"],"email","","inputEmail");
	input("cemail","Confirme seu E-mail","input-xlarge","cemail","Confirme o e-mail informado",true,$_POST["cemail"],"email","","inputCemail");
	input("telefone1","Telefone","input-medium","telefone1","(88) 99999-9999",true,$_POST["telefone1"]);

	input("cep","CEP","input-medium","cep","00000-000",true,$_POST["cep"]);
	input("cidade","Cidade","input-xxlarge uneditable-input","cidade","",false,$_POST["cidade"],'text','readonly');
	input("uf","UF","input-mini uneditable-input","uf","",false,$_POST["uf"],'text','readonly');
	input("nascimento","Data de Nascimento","","nascimento","DD/MM/AAAA",false,$_POST["nascimento"]);

	?>

	<div class="control-group">
		<label for="escolaridade" class="control-label">Escolaridade</label>
		<div class="controls">
			<select size="1" name="escolaridade" id="escolaridade">
				<option value="Fundamental Incompleto" >Fundamental Incompleto</option>
				<option value="Fundamental Completo" >Fundamental Completo</option>
				<option value="Médio Incompleto" >Médio Incompleto</option>
				<option value="Médio Completo">Médio Completo</option>
				<option value="Superior Incompleto">Superior Incompleto</option>
				<option value="Superior Completo"> Superior Completo</option>
			</select>
		</div>
	</div>

	<div class="control-group">
		<label for="ocupacao" class="control-label">Ocupação</label>
		<div class="controls">
			<select size="1" name="ocupacao" id="ocupacao">
				<option value=""></option>
				<option value="estudante">Estudante</option>
				<option value="profissional">Profissional</option>
				<option value="comunidade">Comunidade</option>
			</select>
		</div>
	</div>

	<div class="pEstudantes" style="display:none">

		<div class="control-group">
			<label for="iniciacao" class="control-label">Iniciativa</label>
			<div class="controls">
				<select size="1" name="iniciativa" id="iniciativa">
					<option value="publica">Pública</option>
					<option value="particular">Particular</option>
				</select>
			</div>
		</div>

	<?php
	input("instEnsino","Instituição de Ensino","input-xlarge","instEnsino","Nome da Instituição de Ensino",false,$_POST["instEnsino"]);
	?>

	</div>

	<div class="control-group">
		<label for="sexo" class="control-label">Sexo</label>
		<div class="controls">
			<select size="1" name="sexo" id="sexo">
				<option value="">Não Informado</option>
				<option value="m">Masculino</option>
				<option value="f">Feminino</option>
			</select>
		</div>
	</div>

	<hr/>
	<h2>Minicursos e Oficinas</h2>

	<table class="table table-bordered table-striped">
		<thead>
			<tr>
				<th style="width:30%">Oficina</th>
				<th>Detalhes</th>
				<th>Vagas</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$qryAtividades = $pdo->query("SELECT * FROM atividade ORDER BY titulo");
			while($atividade = $qryAtividades->fetchObject()){

			 ?>
			 <tr>
			 		<td style="font-weight:bold"><?php echo utf8_encode($atividade->titulo) ?></td>
			 		<td><?php echo utf8_encode($atividade->descricao) ?></td>
					<td style="text-align:center">

	<?php
	// Fazendo a contagem de quantos inscritos nas atividades
	$idAtividade = $atividade->id_atividade;
	$qryInscritos = $pdo->query("SELECT id_participante FROM atividade_participante WHERE id_atividade = $idAtividade");
	$total = $qryInscritos->rowCount();
	$total = $atividade->vagas - $total;
	 ?>

						<?php echo $total ?>/<?php echo $atividade->vagas ?><br/>

						<?php if($total > 0){
							?>
	<button type="button" class="btn btn-primary participar" data-toggle="button" data-complete-text="finished!"
	value="<?php echo $atividade->id_atividade;?>">Participar</button>
	<input type="hidden" name="oficinas[]" class="input_participar" value="" id="input_<?php echo $atividade->id_atividade;?>">
						<?php
						} ?>

					</td>
			 </tr>
			 <?php } ?>
		</tbody>
	</table>


	<div class="form-actions">
	<input type="submit" class="btn btn-primary" value="Inscrever-se" name="envio">
	<button type="button" class="btn">Cancelar</button>
	</div>

		</form>

<?php }else{ ?>


	<?php } ?>
          </div>

        </div>

      </div>
    </section>

		<?php require("../rodape.php"); ?>

<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="<?php echo $urlBase; ?>js/vendor/jquery.mask.js"></script>
<script type="text/javascript" src="<?php echo $urlBase; ?>js/bootstrap-alert.js"></script>
<script type="text/javascript" src="<?php echo $urlBase; ?>js/bootstrap-button.js"></script>
<script type="text/javascript">

$('.btn').button();

$('.participar').click(function(e){
	var val = $(this).val();

	if($(this).hasClass('active')){
		$('#input_'+val).val('');
		$(this).removeClass('btn-success');
	}else{
		$('#input_'+val).val(val);
		$(this).addClass('btn-success');
	}
});

$("#ocupacao").change(function(e){

	if($(this).val() == "estudante")
	$(".pEstudantes").slideDown();
	else
	$(".pEstudantes").slideUp();

});

var options =  {
onComplete: function(cepInput) {
		$.ajax({
					dataType:'json',
					method:"GET",
          url:"../consultacep.php",
					data:{ cep: cepInput}
      }).success(function(data){
					if(data[0].cidade && data[0].uf){
						$('#cidade').val(data[0].cidade);
						$('#uf').val(data[0].uf);
					}

      });
  }
};

var optionsCPF =  {
onComplete: function(cpfInput) {
		$.ajax({
					method:"GET",
          url:"../consultacpf.php",
					data:{ cpf: cpfInput}
      }).success(function(data){
				if(data == "error"){
					$(".inputCPF").addClass("error").removeClass("success");
					$(".inputCPF .controls")
					.append('<p class="help-block">CPF inválido ou já utilizado, informe um outro.</p>');
				}else{
					$(".inputCPF").addClass("success").removeClass("error");
						$(".inputCPF .controls .help-block").remove();
				}

      });
  }
};

$("#email").blur(function(e){
	e.preventDefault();
	var email = $(this).val();
	if(testEmail != ''){

			var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		if (testEmail.test(email)){

			$(".inputEmail").addClass("success").removeClass("error");
			$(".inputEmail .controls .help-block").remove();
			// Passou no teste
			// Verificar se existe no BD
			/**
			$.ajax({
						method:"GET",
						url:"../consultaemail.php",
						data:{ email: testEmail}
				}).success(function(data){
						if(data == "error")
							alert("já existe");
						else
							$(this).toggleClass("success");
				});
			*/
		}else{
			$(".inputEmail").addClass("error").removeClass("success");
			$(".inputEmail .controls")
			.append('<p class="help-block">E-mail inválido ou já informado. Tente um outro.</p>');
		}


	}
    // Não passou
});

$("#cemail").blur(function(e){
	var email 	= $("#email").val();
	var cemail 	= $("#cemail").val();

	if((email == cemail) && (email != ''))
		$(".inputCemail").addClass("success").removeClass("error");
	else
		$(".inputCemail").addClass("error").removeClass("success");

});

	$('#cep').mask('00000-000', options);
	$('#cpf').mask('000.000.000-00', optionsCPF);
	$('#telefone1').mask('(00) 00000-0000');
	$('#nascimento').mask('00/00/0000');
</script>

	</body>
</html>
